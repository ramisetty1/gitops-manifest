## What this does?
This repo along with https://github.com/saha-rajdeep/kubernetescode creates a Jenkins pipeline with GitOps to deploy code into a Kubernetes cluster. CI part is done via Jenkins and CD part via ArgoCD (GitOps).


Please refer to the https://github.com/saha-rajdeep/kubernetescode/blob/main/README.md for the instructions on how to use the codes.
